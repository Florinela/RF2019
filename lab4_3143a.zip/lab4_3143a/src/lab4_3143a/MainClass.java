package lab4_3143a;

public class MainClass {
	public static void main(String[] args) {
		double[][] learningSet;
		try {
			learningSet = UtileFile.readLearningSetFromFile("D:\\Student\\lab4_3143a\\in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
			for(int patternIndex = 1; patternIndex < numberOfPatterns;patternIndex++) {
				
			
			System.out.println("Euclidian distance between first pattern and pattern "
					+ patternIndex + " is " + Distance.calculateEuclidianDistance(learningSet[0], learningSet[patternIndex]));
			}
			double[][] distanceMatrix = new double[numberOfPatterns][numberOfPatterns];
			for (int i=0; i<numberOfPatterns; i++ )
			{
				for (int j=0; j<i; j++ )
				{
					distanceMatrix[i][j] = distanceMatrix[j][i] = Distance.calculateEuclidianDistance(learningSet[i], learningSet[j]);
				}
			}
			for (int i=0; i<numberOfPatterns; i++ )
			{
				for (int j=0; j<numberOfPatterns; j++ )
				{
					System.out.print(distanceMatrix[i][j] + " ");
				}
				System.out.println();
			}
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

}
