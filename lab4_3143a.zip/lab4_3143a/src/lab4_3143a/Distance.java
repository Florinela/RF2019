package lab4_3143a;

public class Distance {
public static double calculateEuclidianDistance(double[] a, double[] b) {
		
		double euclidianDistance = 0;
		for (int i = 0 ; i<a.length;i++)
		{
			euclidianDistance += Math.pow((a[i] - b[i]),2);
		}
		euclidianDistance= Math.floor(Math.sqrt(euclidianDistance)*100)/100;
		return euclidianDistance;
		
	}
}
