package lab4_3143a;

public class USVInputFileCustomException extends Exception{

	public USVInputFileCustomException(String message) {
		super(message);
	}

}
