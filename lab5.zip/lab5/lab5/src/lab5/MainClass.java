package lab5;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] learningSet;
		try {
			learningSet = UtilesFile.readLearningSetFromFile("data.txt");
			int numberOfPatterns=learningSet.length;
			int numberOfFeatures=learningSet[0].length;
			
			System.out.println(String.format("The learning set has %s patterns and %s features", numberOfPatterns, numberOfFeatures));
			
			double[][] newPatterns= UtilesFile.initNewPatterns();
			
			double[][] distances= new double[newPatterns.length][numberOfPatterns];
			
			for( int i=0; i<newPatterns.length;i++)
			{
				for(int j=0;j<numberOfPatterns;j++)
				{
					distances[i][j] = Distance.calculateSimpleEuclidian(newPatterns[i], learningSet[j]);
				}
				
			}
			//UtilesFile.ShowTheDistances(distances, newPatterns.length, numberOfPatterns);
		}
		catch(USVInputFileCustomException e)
		{
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("Finished learning set operations");
			
		}
		
		
	}

}
