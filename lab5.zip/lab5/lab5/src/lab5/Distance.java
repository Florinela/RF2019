package lab5;

public class Distance {
public static double calculateEuclidianDistance(double[] a, double[] b) {
		
		double euclidianDistance = 0;
		for (int i = 0 ; i<a.length;i++)
		{
			euclidianDistance += Math.pow((a[i] - b[i]),2);
		}
		euclidianDistance= Math.floor(Math.sqrt(euclidianDistance)*100)/100;
		return euclidianDistance;
		
	}

	public static double calculateSimpleEuclidian(double[] pattern1, String[] pattern2)
	{
		double distance = 0.0;
		for(int feature=0;feature<2;feature++)
		{
		distance+=Math.pow(pattern1[feature] - Double.valueOf(pattern2[feature]), 2);
		
		}
		return Math.sqrt(distance);
	}
}
