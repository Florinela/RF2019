package rf_lab1;

public class MainClass {

	private static double[][] normalizeLearningSet(double[][] learningSet)
	{
	double[][] normalizedLearningSet = new double[learningSet.length][];	
	int j=0;
	do
	{
		//find minimum and maximum
		double minim, maxim;
		minim=learningSet[0][j];
		maxim=learningSet[0][j];
		for(int i=1;i<learningSet.length-1;i++)
		{
			if(minim>learningSet[i][j])
				minim=learningSet[i][j];
			if(maxim<learningSet[i][j])
				maxim=learningSet[i][j];
		}
		// normalizedLearningSet
		for(int i=0;i<learningSet.length-1;i++)
		{
			if(learningSet[i][j]==minim)
				normalizedLearningSet[i][j]= 0;
			else
				if(learningSet[i][j]==maxim)
				normalizedLearningSet[i][j]=1;
				else
					normalizedLearningSet[i][j]=(learningSet[i][j]-minim)/(maxim-minim);
		}
		j++;
		
	}while(j<learningSet.length-1);
	return normalizedLearningSet;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double[][] learningSet = FileUtils.readLearningSetFromFile("D:\\C4\\RF\\lab1\\in.txt");
		 FileUtils.writeLearningSetToFile("D:\\C4\\RF\\lab1\\out.txt",normalizeLearningSet(learningSet));

	}

}
